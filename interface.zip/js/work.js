var $canvas = document.querySelectorAll('.list');
var clickTimer = null;
var listDetail = document.getElementsByClassName('list-detail')
var favoriteBox = document.getElementsByClassName('favorite-box')

for(var i = 0;i<$canvas.length; i++ ) {
    $canvas[i].addEventListener("click", handleOnlySingleClick);
    $canvas[i].addEventListener("dblclick", handleOnlyDoubleClick);
}

var favorite = document.getElementsByClassName('favorite')
var listBox = document.getElementsByClassName('list-box')
var detail = document.getElementsByClassName('list-detail')
var chartBox = document.getElementsByClassName('chartBox')
var imgElement = document.getElementById('img');

function handleOnlySingleClick(event) {
    if (event.detail === 1) {
        clickTimer = setTimeout(() => {
            handleSingleClick(event)
        }, 200)
    }
}
function handleOnlyDoubleClick() {
    clearTimeout(clickTimer)
    handleDoubleClick(event)
}
function handleSingleClick() {
    console.log('单击事件')
}
function handleDoubleClick() {
    console.log('双击事件')
    listDetail[0].style.display="flex"
    listBox[0].style.display="none"
}

function createMenuItem(name) {
    let li = document.createElement('div');
    li.className="list-1"
    li.innerHTML = name;
    return li;
  }
  
  function shou() {
    imgElement.src='./image/xin.png'
    var addInfo = document.getElementById('favorite-box')
    var html = '<img src="./image/cover.jpg" alt="">'+
        '<div class="info">'+
            '<div>Name:XXX</div>'+
            '<div>Address:XXXX</div>'+
            '<div>Allergy:XXXX</div>'+
            '<div>Preference:XXX</div>'+
        '</div>';
    addInfo.appendChild(createMenuItem(html))
  }

  function favoriteShow() {
    listBox[0].style.display="none"
    favorite[0].style.display="flex"
    detail[0].style.display="none"
    chartBox[0].style.display="none"
  }

  function AllergyFun() {
    listBox[0].style.display="flex"
    favorite[0].style.display="none"
    detail[0].style.display="none"
    chartBox[0].style.display="none"
    imgElement.src='./image/xin2.png'
  }

  function GroupFun() {
    listBox[0].style.display="none"
    favorite[0].style.display="none"
    detail[0].style.display="none"
    chartBox[0].style.display="flex"
  }



  function createMenuItem1(name) {
    let li = document.createElement('div');
    li.className="list-in"
    li.innerHTML = name;
    return li;
  }
  function handleEnter(event, inputElement) {
    console.log();
    if(event.key === 'Enter') {
        event.preventDefault();
        var chart = document.getElementById('chart')
        var html = '<div class="content">'+document.getElementById('myInput').value+'</div>'+
        '<img src="./image/2.jpg" alt="">';
        chart.appendChild(createMenuItem1(html))
    }
}